package di.calculator03;

public interface Calculator {
	
	public int calculate(int n1, int n2);
}
