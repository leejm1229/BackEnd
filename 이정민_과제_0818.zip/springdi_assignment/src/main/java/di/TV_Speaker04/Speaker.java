package di.TV_Speaker04;

public interface Speaker {
	
	public void volumeUp();
	public void volumeDown();
	public void getBrand();
}
