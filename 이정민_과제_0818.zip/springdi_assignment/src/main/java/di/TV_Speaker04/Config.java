package di.TV_Speaker04;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = {"di.TV_Speaker04"})
@Configuration
public class Config {

}
