package di.TV_Speaker03;

public interface Speaker {
	public void volumeUp();
	public void volumeDown();
	public void getBrand();
}
