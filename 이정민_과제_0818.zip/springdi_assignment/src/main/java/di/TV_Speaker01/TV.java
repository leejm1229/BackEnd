package di.TV_Speaker01;
 
public interface TV {
	public void powerOn();
	public void powerOff();
	public void volumeUp();
 	public void volumeDown();
 	public void printSpeakerBrand();

}