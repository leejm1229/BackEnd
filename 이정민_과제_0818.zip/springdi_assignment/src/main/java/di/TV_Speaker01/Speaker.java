package di.TV_Speaker01;

public interface Speaker {
	public void volumeUp();
	public void volumeDown();
	public void getBrand();
}
